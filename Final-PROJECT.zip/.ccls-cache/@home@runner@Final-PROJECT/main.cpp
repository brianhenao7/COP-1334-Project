#include <iostream>
#include <string> 
#include <vector>
#include <fstream>
using namespace std;

void show_menu(){
cout << "Menu Items:" << endl;
  
}

void show_phonenumber(){
cout << "Phone Number:" << endl;
  
}

void print_menu(){
cout << " ***********************************" << endl;
    cout << " ***********************************" << endl;
  cout << " " << endl;  
  cout << " Welcome to Italian Restaurant" << endl;
    cout << "m - menu" << endl;
    cout << "p - phone number" << endl;
    cout << "l - leave" << endl;
  cout << " " << endl;
   cout << " ***********************************" << endl;
  cout << " " << endl;
    cout << " Please enter one of the following options  from above:" << endl;
   cout << "  " << endl;
  
}



int main() {
char user_input;

  vector<string> item1;
vector<string> item2;
  vector<string> item3;
  

  
  do {
   print_menu ();
    cin >> user_input;
    switch (user_input){
      case 'm':
        cout << "  " << endl;
show_menu();
        cout << "  " << endl;
        cout << ("pasta") << endl;
        cout << ("pizza") << endl;
        cout << ("salad") << endl;
        cout << "  " << endl;
      break;
      case 'p':
         cout << "  " << endl;
show_phonenumber();
       cout << "  " << endl;
        cout << "1-800-ILOVEPIZZA" << endl;
        cout << "  " << endl;
      break;
      case 'l':
         cout << "  " << endl;
cout << "Bye! Hope to see you soon!" << endl;
        cout << "  " << endl;
      break;
      default:
      cout << "Invalid option, please try again" << endl;
    }
  } while(user_input != 'q');
  
return 0;
  }
















  
